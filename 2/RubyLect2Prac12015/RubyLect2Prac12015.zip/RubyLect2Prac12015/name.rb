def name_print
	puts "Xiaosheng Liang"
end

name_print
