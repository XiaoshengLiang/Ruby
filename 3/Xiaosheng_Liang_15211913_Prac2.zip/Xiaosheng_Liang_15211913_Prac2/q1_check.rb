def print_error
    puts "error: divisor can't be 0"
end