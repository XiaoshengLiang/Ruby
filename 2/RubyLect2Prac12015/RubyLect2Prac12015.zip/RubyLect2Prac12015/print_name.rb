def print_name
	print "The name is: ", ARGV[0]," ",ARGV[1],"\n"
end

print_name
