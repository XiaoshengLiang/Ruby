def division(num1,num2)
	res=num1/num2
	puts "The result is:"
	puts res
end
