require 'test_helper'

class OtherHelperTest < ActionView::TestCase
end
