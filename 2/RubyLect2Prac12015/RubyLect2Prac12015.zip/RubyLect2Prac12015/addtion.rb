def two_numbers_addtion
	print("my_add_five_to_six=>",5+6,"\n")
end

two_numbers_addtion
