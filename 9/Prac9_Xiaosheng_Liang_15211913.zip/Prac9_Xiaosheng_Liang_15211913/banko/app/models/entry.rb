class Entry < ActiveRecord::Base
end
