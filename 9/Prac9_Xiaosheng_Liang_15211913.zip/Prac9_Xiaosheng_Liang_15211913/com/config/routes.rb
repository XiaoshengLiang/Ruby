Rails.application.routes.draw do
  get 'main/welcome'

  get 'main/goodbye'

  get 'main/input'

  get 'main/check'

  get 'main/show'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
